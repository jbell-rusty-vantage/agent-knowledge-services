---
id: "op:create_work"
kind: operation
name: create_work
dispatcher: command
function: product.dispatch_command
call: api.product_command
lens: ours
relations: [authoring.work]
tokens: [create_work, command, api.product_command]
workspace_fingerprint: "sha256:db20bac4d9e82d9b94cd2f3b580d4c145bcc3820969fdd572c6e7868ecca53fd"
---
# create_work

Product operation: the `when 'create_work' then` arm of [`product.dispatch_command`](../functions/product/dispatch_command.md) (dispatcher `command`), reached through [`api.product_command`](../functions/api/product_command.md). Derived from the function body; relation list is best effort.

## How to call

```sql
select api.product_command(p_workspace_id, 'create_work', p_idempotency_key, p_expected_head, p_payload)
```
Execute: `authenticated`. The payload is a JSON object; errors come back as `product.fail(code, detail)` exceptions.

## Relations the arm touches

| Relation | Access |
| --- | --- |
| [`authoring.work`](../relations/authoring/work.md) | write |

## Helpers called

[`product.fail`](../functions/product/fail.md), [`product.insert_revision`](../functions/product/insert_revision.md), [`product.require_role`](../functions/product/require_role.md)
