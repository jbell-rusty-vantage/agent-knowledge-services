---
id: "rel:retrieval.content_promotion_decision"
kind: table
schema: retrieval
name: content_promotion_decision
domain: retrieval
lens: corpus
aliases: []
tokens: [retrieval, content_promotion_decision, retrieval.content_promotion_decision, id, tenant_id, proposal_id, guarded_sha256, decision, gates, reviewer_identity, policy_version, rationale, expires_at, created_at, knowledge_review_decision_id, decision_operation_id, legacy_provenance]
summary: null
summary_basis: none
rls: enabled
readers: []
writers: []
typescript: "Database[\"retrieval\"][\"Tables\"][\"content_promotion_decision\"][\"Row\"]"
defined_in: ["20260903010100_knowledge_retrieval_contract.sql"]
workspace_fingerprint: "sha256:3cbce2e1f51948facb352a727c22966b1e5ceea4646ae43b07860ce6e83127b4"
---
# retrieval.content_promotion_decision

table in domain `retrieval`, lens `corpus`.

## Columns

| # | Column | Type | Null | Default | Notes |
| ---: | --- | --- | --- | --- | --- |
| 1 | `id` | `uuid` | no | `util.uuidv7()` | PK; unique (tenant_id, id) |
| 2 | `tenant_id` | `uuid` | no | `util.default_tenant_id()` | unique (tenant_id, id) |
| 3 | `proposal_id` | `uuid` | no | — | — |
| 4 | `guarded_sha256` | `text` | no | — | — |
| 5 | `decision` | `text` | no | — | — |
| 6 | `gates` | `jsonb` | no | — | — |
| 7 | `reviewer_identity` | `text` | no | — | — |
| 8 | `policy_version` | `text` | no | — | — |
| 9 | `rationale` | `text` | no | — | — |
| 10 | `expires_at` | `timestamp with time zone` | yes | — | — |
| 11 | `created_at` | `timestamp with time zone` | no | `now()` | — |
| 12 | `knowledge_review_decision_id` | `uuid` | yes | — | — |
| 13 | `decision_operation_id` | `uuid` | yes | — | — |
| 14 | `legacy_provenance` | `boolean` | no | `false` | — |

## Constraints

- PK (id)
- unique (tenant_id, id)
- check `content_promotion_decision_decision_check`: `(decision = ANY (ARRAY['accept'::text, 'reject'::text, 'defer'::text, 'request_changes'::text]))`
- check `content_promotion_decision_guarded_sha256_check`: `(guarded_sha256 ~ '^[0-9a-f]{64}$'::text)`
- check `content_promotion_decision_provenance_ck`: `((legacy_provenance AND (num_nonnulls(knowledge_review_decision_id, decision_operation_id) = 0)) OR ((NOT legacy_provenance) AND (num_nonnu…`

## Relationships

Outbound: `tenant_id,decision_operation_id` → [`knowledge_service.operation`](../knowledge_service/operation.md)`.tenant_id,id` on delete restrict; `tenant_id,knowledge_review_decision_id` → [`knowledge_service.review_decision`](../knowledge_service/review_decision.md)`.tenant_id,id` on delete restrict; `tenant_id,proposal_id` → [`retrieval.content_promotion_proposal`](content_promotion_proposal.md)`.tenant_id,id` on delete restrict.
Inbound: [`retrieval.embedding_run`](embedding_run.md).promotion_decision_id, [`retrieval.search_projection`](search_projection.md).content_promotion_decision_id, [`retrieval.space_publication`](space_publication.md).publication_decision_id.

## Indexes

`content_promotion_decision_tenant_id_id_key` unique

## Triggers

- `content_promotion_decision_immutable` → [`util.reject_mutation`](../../functions/util/reject_mutation.md)
- `promotion_decision_no_new_legacy` → [`retrieval.reject_new_legacy_governance_provenance`](../../functions/retrieval/reject_new_legacy_governance_provenance.md)

## Row-level security

Enabled.
- `bounded_role_access` (ALL) for `app_reader`, `control_plane`, `executor_service`, `pipeline_agent`, `verifier_agent`: `(tenant_id = util.current_tenant_id())`

## Grants

No role has privileges. None: `anon`, `app_reader`, `authenticated`, `control_plane`, `executor_service`, `pipeline_agent`, `service_role`, `verifier_agent`.

## Read paths

- No agent role may SELECT directly.

## Write path

- No direct DML for any agent role.
- No write path for agents; rows are seeded by migrations or platform tooling.

## TypeScript

insert: `Database["retrieval"]["Tables"]["content_promotion_decision"]["Insert"]`; row: `Database["retrieval"]["Tables"]["content_promotion_decision"]["Row"]`; update: `Database["retrieval"]["Tables"]["content_promotion_decision"]["Update"]`

Defined in: `20260903010100_knowledge_retrieval_contract.sql`.
