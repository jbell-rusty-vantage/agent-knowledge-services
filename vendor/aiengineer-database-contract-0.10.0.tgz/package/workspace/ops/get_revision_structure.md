---
id: "op:get_revision_structure"
kind: operation
name: get_revision_structure
dispatcher: authoring
function: product.dispatch_authoring_read
call: api.product_read
lens: ours
relations: [authoring.revision_binding, authoring.runtime_requirement, authoring.work, authoring.work_revision, curriculum.outcome, curriculum.outcome_alignment, curriculum.part, curriculum.prerequisite, curriculum.requirement, curriculum.requirement_option, inquiry.assertion]
tokens: [get_revision_structure, authoring, api.product_read]
workspace_fingerprint: "sha256:3cbce2e1f51948facb352a727c22966b1e5ceea4646ae43b07860ce6e83127b4"
---
# get_revision_structure

Product operation: the `when 'get_revision_structure' then` arm of [`product.dispatch_authoring_read`](../functions/product/dispatch_authoring_read.md) (dispatcher `authoring`), reached through [`api.product_read`](../functions/api/product_read.md). Derived from the function body; relation list is best effort.

## How to call

```sql
select api.product_read(p_workspace_id, 'get_revision_structure', p_payload)
```
Execute: `authenticated`. The payload is a JSON object; errors come back as `product.fail(code, detail)` exceptions.

## Relations the arm touches

| Relation | Access |
| --- | --- |
| [`authoring.revision_binding`](../relations/authoring/revision_binding.md) | read |
| [`authoring.runtime_requirement`](../relations/authoring/runtime_requirement.md) | read |
| [`authoring.work`](../relations/authoring/work.md) | read |
| [`authoring.work_revision`](../relations/authoring/work_revision.md) | read |
| [`curriculum.outcome`](../relations/curriculum/outcome.md) | read |
| [`curriculum.outcome_alignment`](../relations/curriculum/outcome_alignment.md) | read |
| [`curriculum.part`](../relations/curriculum/part.md) | read |
| [`curriculum.prerequisite`](../relations/curriculum/prerequisite.md) | read |
| [`curriculum.requirement`](../relations/curriculum/requirement.md) | read |
| [`curriculum.requirement_option`](../relations/curriculum/requirement_option.md) | read |
| [`inquiry.assertion`](../relations/inquiry/assertion.md) | read |

## Helpers called

[`product.fail`](../functions/product/fail.md), [`product.role_in`](../functions/product/role_in.md), [`product.tenant`](../functions/product/tenant.md)
