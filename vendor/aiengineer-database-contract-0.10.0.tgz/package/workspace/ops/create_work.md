---
id: "op:create_work"
kind: operation
name: create_work
dispatcher: command
function: product.dispatch_command
call: api.product_command
lens: ours
relations: [authoring.work]
tokens: [create_work, command, api.product_command]
workspace_fingerprint: "sha256:3cbce2e1f51948facb352a727c22966b1e5ceea4646ae43b07860ce6e83127b4"
---
# create_work

Product operation: the `when 'create_work' then` arm of [`product.dispatch_command`](../functions/product/dispatch_command.md) (dispatcher `command`), reached through [`api.product_command`](../functions/api/product_command.md). Derived from the function body; relation list is best effort.

## How to call

```sql
select api.product_command(p_workspace_id, 'create_work', p_idempotency_key, p_expected_head, p_payload)
```
Execute: `authenticated`. The payload is a JSON object; errors come back as `product.fail(code, detail)` exceptions.

## Relations the arm touches

| Relation | Access |
| --- | --- |
| [`authoring.work`](../relations/authoring/work.md) | write |

## Helpers called

[`product.fail`](../functions/product/fail.md), [`product.insert_revision`](../functions/product/insert_revision.md), [`product.require_role`](../functions/product/require_role.md)
