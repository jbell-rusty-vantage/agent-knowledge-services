---
id: "rel:evidence.locator"
kind: table
schema: evidence
name: locator
domain: evidence
lens: evidence
aliases: [quote, selector]
tokens: [evidence, locator, evidence.locator, id, capture_id, media_type, selector, selected_content_sha256, normalized_value, context_fingerprint, extractor_name, extractor_version, extraction_params, created_at, tenant_id, verification_contract_version, representation_artifact_id, selector_sha256, selected_size_bytes, occurrence_count, resolution_state, normalization_policy, resolution_version, selector_kind, start_ms, end_ms, page_number]
summary: "Precise selection inside a capture (text quote, table cell, timecode, page+bbox) with selected_content_sha256 and a normalized value."
summary_basis: curated
rls: enabled
readers: [executor_service, pipeline_agent, service_role, verifier_agent]
writers: [executor_service, pipeline_agent, service_role, verifier_agent]
typescript: "Database[\"evidence\"][\"Tables\"][\"locator\"][\"Row\"]"
defined_in: ["20260826000300_evidence_core.sql"]
workspace_fingerprint: "sha256:216c4ae7230478c8e60934da25c852e10680d6caed71a662962ea3c0ac1676d3"
---
# evidence.locator

table in domain `evidence`, lens `evidence`.

> curated (model_assisted, unreviewed) — Precise selection inside a capture (text quote, table cell, timecode, page+bbox) with selected_content_sha256 and a normalized value.

## Columns

| # | Column | Type | Null | Default | Notes |
| ---: | --- | --- | --- | --- | --- |
| 1 | `id` | `uuid` | no | `util.uuidv7()` | PK; unique (tenant_id, id) |
| 2 | `capture_id` | `uuid` | no | — | FK → [`evidence.source_capture`](source_capture.md).id |
| 3 | `media_type` | `text` | no | — | — |
| 4 | `selector` | `jsonb` | no | — | — |
| 5 | `selected_content_sha256` | `text` | yes | — | _curated:_ Digest of the selected span, not the whole capture. |
| 6 | `normalized_value` | `text` | yes | — | _curated:_ The value as read, normalized (api.fact_locators shows it beside the fact's amount). |
| 7 | `context_fingerprint` | `text` | yes | — | — |
| 8 | `extractor_name` | `text` | no | — | — |
| 9 | `extractor_version` | `text` | no | — | — |
| 10 | `extraction_params` | `jsonb` | no | `'{}'::jsonb` | — |
| 11 | `created_at` | `timestamp with time zone` | no | `now()` | — |
| 12 | `tenant_id` | `uuid` | yes | — | unique (tenant_id, id) |
| 13 | `verification_contract_version` | `text` | yes | — | — |
| 14 | `representation_artifact_id` | `uuid` | yes | — | — |
| 15 | `selector_sha256` | `text` | yes | — | — |
| 16 | `selected_size_bytes` | `bigint` | yes | — | — |
| 17 | `occurrence_count` | `integer` | yes | — | — |
| 18 | `resolution_state` | `text` | yes | — | — |
| 19 | `normalization_policy` | `text` | yes | — | — |
| 20 | `resolution_version` | `text` | yes | — | — |
| 21 | `selector_kind` | `text` | no | `'text_quote'::text` | _curated:_ text_quote, table, media_timecode, page_bbox, json_pointer, line_range. |
| 22 | `start_ms` | `integer` | yes | — | _curated:_ Timecode locators: window start in milliseconds. |
| 23 | `end_ms` | `integer` | yes | — | — |
| 24 | `page_number` | `integer` | yes | — | — |

## Constraints

- PK (id)
- unique (tenant_id, id)
- 12 check constraints; see [details](locator.details.md)

## Relationships

3 outbound and 19 inbound foreign keys; full list in [details](locator.details.md).

## Indexes

2 indexes; see [details](locator.details.md).

## Triggers

3 triggers; see [details](locator.details.md).

## Row-level security

Enabled; 1 policies in [details](locator.details.md).

## Grants

`executor_service`: INSERT, SELECT, UPDATE; `pipeline_agent`: INSERT, SELECT; `service_role`: INSERT, SELECT, UPDATE; `verifier_agent`: INSERT, SELECT. None: `anon`, `app_reader`, `authenticated`, `control_plane`.

## Read paths

- Named queries: `q:facts.locators`.
- Exposed through: [`api.claim_surfaces`](../api/claim_surfaces.md).
- Direct SELECT: `executor_service`, `pipeline_agent`, `verifier_agent`.

## Write path

- Direct DML: `executor_service`, `pipeline_agent`, `verifier_agent`.
- Via functions (best effort): [`verification.chain_anchor`](../../functions/verification/chain_anchor.md).

## TypeScript

insert: `Database["evidence"]["Tables"]["locator"]["Insert"]`; row: `Database["evidence"]["Tables"]["locator"]["Row"]`; update: `Database["evidence"]["Tables"]["locator"]["Update"]`

## Examples

Where a current price was read

```bash
knowledge db query facts.locators --param entity_id=0192b000-0000-7000-8000-000000000001 --param scope_key=null --param stream_kind=offering_price
```
Returns locator, capture URL/time and the typed unit (document_node_id).

Defined in: `20260826000300_evidence_core.sql`.
