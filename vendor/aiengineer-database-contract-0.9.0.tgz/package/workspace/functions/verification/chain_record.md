---
id: "fn:verification.chain_record(text,jsonb,jsonb,jsonb,jsonb)"
kind: function
schema: verification
name: chain_record
domain: evidence
lens: evidence
overloads: ["fn:verification.chain_record(text,jsonb,jsonb,jsonb,jsonb)"]
security: invoker
volatility: volatile
executors: []
raises: []
touches: { reads: [], writes: [orchestration.operation_intent, orchestration.operation_receipt] }
tokens: [verification, chain_record, verification.chain_record]
defined_in: ["20261116130000_build08_governed_chain_writes.sql"]
workspace_fingerprint: "sha256:216c4ae7230478c8e60934da25c852e10680d6caed71a662962ea3c0ac1676d3"
---
# verification.chain_record

Domain `evidence`, lens `evidence`.

## chain_record(text, jsonb, jsonb, jsonb, jsonb) → jsonb

function, volatile, security invoker, language plpgsql, config `search_path=""`.

| Argument | Type | Default | Mode |
| --- | --- | --- | --- |
| `p_function` | `text` | — | — |
| `p_ctx` | `jsonb` | — | — |
| `p_request` | `jsonb` | — | — |
| `p_result` | `jsonb` | — | — |
| `p_refs` | `jsonb` | — | — |

Execute: no configured role.

Touches (best effort): reads —; writes [`orchestration.operation_intent`](../../relations/orchestration/operation_intent.md), [`orchestration.operation_receipt`](../../relations/orchestration/operation_receipt.md); calls [`util.uuidv7`](../util/uuidv7.md).

TypeScript: `Database["verification"]["Functions"]["chain_record"]`.

Defined in: `20261116130000_build08_governed_chain_writes.sql`.
